package edu.url.salle.albert.gt.evased;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import edu.url.salle.albert.gt.evased.databinding.ActivityMyMessagesBinding;
import edu.url.salle.albert.gt.evased.databinding.ActivityTimelineBinding;

public class MyMessagesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_messages);
    }
}