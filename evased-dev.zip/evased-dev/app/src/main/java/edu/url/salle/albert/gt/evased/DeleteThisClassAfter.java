package edu.url.salle.albert.gt.evased;

import androidx.appcompat.app.AppCompatActivity;

public class DeleteThisClassAfter extends AppCompatActivity {
}
