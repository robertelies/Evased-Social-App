package edu.url.salle.albert.gt.evased;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class past_events_review extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_past_events_review);
    }
}